import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cDovL3d3dy5tYXZlcmlja3JlcG8ubmV0L2RhdGEvaG9tZS9ob21lLnhtbA==')
addon = xbmcaddon.Addon('plugin.video.MaverickTV')