import xbmcaddon

MainBase = 'http://stephen-builds.uk/supremacy/home.txt'
addon = xbmcaddon.Addon('plugin.video.supremacy')